def avg(sales):
    return sum(sales) / len(sales)

with open("sales_data4.txt") as f:
    sales_lst = [int(s) for s in f.readlines()]
    print(f"Total sales: {sum(sales_lst)}")
    print(f"Highest sale: {max(sales_lst)}")
    print(f"Lowest sale: {min(sales_lst)}")
    print(f"Average sale: {avg(sales_lst)}")
    