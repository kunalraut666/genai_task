new_sales = ['5000', '2500', '1700']
with open("sales_data3.txt", "a") as f:
    for n in new_sales:
        f.write(f"{n}\n")


with open("sales_data3.txt", "r") as f:
    content_data = f.read()
    print(content_data)
    f.seek(0)
    all_lines = f.readlines()

print(f"Total no of lines: {len(all_lines)}")
