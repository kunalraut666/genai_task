sales = [1200, 450, 980, 1500, 3000]

f = open("sales_data.txt", "w")\

f.write(str(sales[0]))

for s in range(1, len(sales)):
    f.write(f"\n{str(sales[s])}")

f.close()

f = open("sales_data.txt", "r")

print(f.read())

f.close()

with open("sales_data.txt", "a") as f:
    f.write("\n")
    for sale in sales:
        f.write(f"{str(sale)},")


f = open("sales_data.txt", "r")

print(f.read())

f.close()