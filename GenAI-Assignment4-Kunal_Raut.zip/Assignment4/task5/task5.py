products = input("Enter three products name followed by price:").split(" ")

with open("products.txt", "w") as f:
    for p in range(0, len(products), 2):
        f.write(f"{products[p]} | {products[p+1]}\n")

with open("products.txt", "r") as f:
    for line in f.readlines():
        print(line)