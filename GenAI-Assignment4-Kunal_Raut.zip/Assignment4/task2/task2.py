lst = []

with open("sales_data.txt", "r") as f:
    content_data = f.read()
    print(f"Full content: {content_data}")
    f.seek(0)

    one_line = f.readline()
    print(f"One line: {one_line}")
    f.seek(0)

    all_lines = f.readlines()
    print(f"All Lines: {all_lines}")

    for line in all_lines:
        lst.append(int(line))

for l in lst:
    print(type(l))