prices = {
    "Mouse": 500,
    "Keyboard": 800,
    "Monitor": 7000,
    "Pendrive": 400,
    "Camera": 5000
}

discount = int(input("Enter discount percentage: "))

discounted_prices = list(map(lambda x : x - (x * discount) / 100, prices.values()))

with open("discount_report.txt", "w+") as f:      
    for i,key in enumerate(prices):
        f.write(f"{key} | {prices[key]} | {discounted_prices[i]}\n")

    f.write(f"Total items: {len(prices)}\nAverage discounted price: {sum(discounted_prices) / len(discounted_prices)}")

    f.seek(0)
    print(f.read())