# reads an integer order_amount, converting input() str to int, handling invalid input
try:
    order_amount = int(input())
except Exception as e:
    raise ValueError("Please provide numeric value")

# logic for calculating discount
def discount_calculator(n):
    if n >= 2000:
        return ((n*15) / 100, "15%")
    elif n >= 1500:
        return ((n*10) / 100, "10%")
    elif n >= 1000:
        return ((n*7) / 100, "7%")
    else:
        return (0, "0%")

# final payment after discount    
res = discount_calculator(order_amount)
print(f"You have to pay: {order_amount - res[0]} \nYou get {res[1]} discount!")

# payment after applying discount
tax = 5
print(f"Your total is :{order_amount - res[0]} after adding {tax}% tax your total payment is: {(order_amount - res[0]) + (order_amount - res[0]) * tax / 100}")