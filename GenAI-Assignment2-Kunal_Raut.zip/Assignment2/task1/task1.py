# reads an integer order_amount, converting input() str to int, handling invalid input
# this try except is simple block, I'm a software engineer and will write this kind of blocks very often I haven't used AI for writing these code.
# try:
#     order_amount = int(input())
# except Exception as e:
#     raise ValueError("Please provide numeric value")

order_amount = input()
if not order_amount.isdigit():
    raise ValueError("Please provide numeric value")

order_amount = int(order_amount)
# logic for calculating discount
discount_amount = 0
discount_percentage = ""

if order_amount >= 2000:
    discount_amount = (order_amount * 15) / 100 
    discount_percentage = "15%"
elif order_amount >= 1500:
    discount_amount = (order_amount * 10) / 100 
    discount_percentage = "10%"
elif order_amount >= 1000:
    discount_amount = (order_amount * 7) / 100
    discount_percentage = "7%"
else:
    discount_amount = 0 
    discount_percentage = "0%"

# final payment after discount
total_payment = order_amount - discount_amount    
print(f"You have to pay: {total_payment} \nYou get {discount_percentage} discount!")

# payment after applying discount
tax = 5
print(f"Your total is :{total_payment} after adding {tax}% tax your total payment is: {total_payment + (total_payment) * tax / 100}")