# order list
orders = [1200, 2500, 800, 1750, 3000]
revenue = 0
total_no_of_discount = 0

# characters for depicting table
print("-" * 45)
print(f"{'Order amount':<15}{'Discount':<12}{'Final Amount'}")
print("-" * 45)
for od in orders:
    if od >= 2000:
        discount_amount = (od * 15) / 100 
        discount_percentage = "15%"
    elif od >= 1500:
        discount_amount = (od * 10) / 100 
        discount_percentage = "10%"
    elif od >= 1000:
        discount_amount = (od * 7) / 100
        discount_percentage = "7%"
    else:
        discount_amount = 0 
        discount_percentage = "0%"
    
    if discount_amount > 0:
        total_no_of_discount += 1

    final_amount = od - discount_amount
    revenue += final_amount
    print(f"{od:<15}{discount_percentage:<12}{final_amount}")
print("-" * 45)

# total revenue and total no of orders got discount
print(f"Total revenue: {revenue}")
print(f"Total no of orders got dicount: {total_no_of_discount}")