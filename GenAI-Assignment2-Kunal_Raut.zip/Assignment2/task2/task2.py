# logic for discount calculation
def discount_calculator(n):
    if n >= 2000:
        return ((n*15) / 100, "15%")
    elif n >= 1500:
        return ((n*10) / 100, "10%")
    elif n >= 1000:
        return ((n*7) / 100, "7%")
    else:
        return (0, "0%")
    
# order list
orders = [1200, 2500, 800, 1750, 3000]
revenue = 0
total_no_of_discount = 0

# characters for depicting table
print("-" * 45)
print(f"{'Order amount':<15}{'Discount':<12}{'Final Amount'}")
print("-" * 45)
for od in orders:
    res = discount_calculator(od)
    if res[0] > 0:
        total_no_of_discount += 1

    final_amount = od - res[0]
    revenue += final_amount
    print(f"{od:<15}{res[1]:<12}{final_amount}")
print("-" * 45)

# total revenue and total no of orders got discount
print(f"Total revenue: {revenue}")
print(f"Total no of orders got dicount: {total_no_of_discount}")