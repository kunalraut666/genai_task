# product list
products = {
    "Keyboard": 1599,
    "Headphones": 4500,
    "Organizer": 399,
    "Scale": 229,
    "Trimmer": 1299,
    "Drone": 45000,
    "Crayons": 359,
    "Wallet": 599,
    "Smartwatch": 3500,
    "Speaker": 2999,
    "Mouse": 799,
    "Backpack": 1199
}

# logic for discount calculation
def discount_calculator(n):
    if n >= 2000:
        return ((n*15) / 100, "15%")
    elif n >= 1500:
        return ((n*10) / 100, "10%")
    elif n >= 1000:
        return ((n*7) / 100, "7%")
    else:
        return (0, "0%")

# showing product list     
print("-" * 45)
print(f"{'Product List':^20}")
print(f"{'Sr No.':<10}{'Product name': <15}{'Price'}")
sr_no = 0
for key, val in products.items():
    sr_no += 1
    print(f"{sr_no:<10}{key:<15}{val}")

selection = list(products.keys())
cart = []
orders = []

# while-loop driven menu system
while True:
    print("Menu Options")
    print("1 - Add order.")
    print("2 - Show all orders and total after discount.")
    print("q - Quit")

    n = input("Enter Choice: ")

    # menu 1 add product
    if n == "1":
        prod = int(input("Select product sr no to select: "))
        if prod < 1 or prod > len(selection):
            print("Product is not avaialble pls select from the above given list")
            continue
        else:
            cart.append(products[selection[prod-1]])
            orders.append(selection[prod-1])
    
    # menu 2 show products and total payment
    elif n == "2":
        if len(cart) == 0:
            print("Your cart is empty")
            continue

        total_payment = 0
        print("Your order list:")
        for od in orders:
            print(od)
        
        for c in cart:
            res = discount_calculator(c)
            total_payment += c - res[0]
        print(f"Your total payment after discount: {total_payment}")

    # menu 3 for quite
    elif n == "q":
        break

    # handling invalid input
    else:
        print("Please select from the above options.")
        continue
