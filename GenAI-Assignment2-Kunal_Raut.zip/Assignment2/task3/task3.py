orders = []

# while-loop driven menu system
while True:
    print("Menu Options")
    print("1 - Add order.")
    print("2 - Show all orders and total after discount.")
    print("q - Quit")

    n = input("Enter Choice: ")

    # menu 1 add product
    if n == "1":
        prod_amount = int(input("Enter amount: "))
        if prod_amount >= 2000:
            discount_amount = (prod_amount * 15) / 100 
            orders.append(prod_amount - discount_amount)
        elif prod_amount >= 1500:
            discount_amount = (prod_amount * 10) / 100 
            orders.append(prod_amount - discount_amount)
        elif prod_amount >= 1000:
            discount_amount = (prod_amount * 7) / 100
            orders.append(prod_amount - discount_amount)
        else:
            discount_amount = 0
            orders.append(prod_amount) 

    # menu 2 show products and total payment
    elif n == "2":
        total_payment = 0
        print("All order:")
        for od in orders:
            print(od)
            total_payment += od

        print(f"Your total payment after discount: {total_payment}")

    # menu 3 for quite
    elif n == "q":
        break

    # handling invalid input
    else:
        print("Please select from the above options.")
        continue
