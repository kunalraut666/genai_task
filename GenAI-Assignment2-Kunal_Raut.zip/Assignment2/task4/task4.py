# daily sales list
daily = [200, 150, 0, 400, 50, -1, 300]

# logic for sales calculation

total_sales = 0

for sale in daily:
    if sale == 0:
        continue
    elif sale == -1:
        break
    else:
        total_sales += sale
        print(f"Running total: {total_sales}")


# final total
print(f"Final Total: {total_sales}")