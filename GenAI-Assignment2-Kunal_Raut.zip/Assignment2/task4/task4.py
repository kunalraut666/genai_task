# daily sales list
daily = [200, 150, 0, 400, 50, -1, 300]

# logic for sales calculation
def calculate_daily_sale(sales):
    total_sales = 0

    for sale in sales:
        if sale == 0:
            continue
        elif sale == -1:
            break
        else:
            total_sales += sale
            print(f"Running total: {total_sales}")

    return total_sales

# final total
print(f"Final Total: {calculate_daily_sale(daily)}")