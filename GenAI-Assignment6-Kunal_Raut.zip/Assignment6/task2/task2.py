prices = [120, 350, 'abc', 500, -200, 800]

def bill_calculator(prices):
    total = 0
    for p in prices:
        try:
            if int(p) < 0:
                raise ValueError("Negative price are not allowed.")
            total += int(p)
        except (TypeError, ValueError) as e:
            continue

    return total

print(bill_calculator(prices))