def open_file(file):
    try:
        with open(file, "r") as f:
            for i in range(3):
                print(f.readline())
    except (FileNotFoundError, PermissionError) as e:
        print(e)

open_file(input("Enter file name: "))