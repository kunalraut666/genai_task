def safe_shopping():
    cart = []

    while True:
        choice = input("Enter amount to add or q to quit: ")

        if choice == "q":
            exit()
        try:
            amount = float(choice)

            if amount < 0:
                raise ValueError("Negative price are not allowed")
            
            cart.append(amount)
            print(f"Total items: {len(cart)}")
            print(f"Total bill: {sum(cart)}")

        except ValueError as e:
            print(e)
        
safe_shopping()