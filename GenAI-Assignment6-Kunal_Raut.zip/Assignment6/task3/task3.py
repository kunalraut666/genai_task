def check_age(age):
    try:
        if age >= 1 and age <= 120:
            print("Age is fine")
        else:
            raise ValueError("Age must be between 1 ans 120")

    except ValueError as e:
       print(e)

check_age(121)