num = input("Enter numerator and denominator: ").split(" ")

try:
    res = int(num[0]) / int(num[1])
    print(f"Result: {res}")
except (ValueError, ZeroDivisionError) as e:
    print(e)

finally:
    print("Operation Complete")
