# product lists with 6 products
products = ["Mouse", "Keyboard", "Headphone", "Laptop", "Mobile", "Pendrive"]

# created categories set from products list
categories = {
    "Mouse": "IT", 
    "Keyboard" : "IT", 
    "Headphone" : "Music", 
    "Laptop" : "IT", 
    "Mobile" : "Electronics", 
    "Pendrive" : "Storage"
}

# extracted all the unique categories from categories set
categories_set = {item for item in categories.values()}

print(categories_set)

# demonstration of adding new categories to the set, duplicates are ignored
categories_set.add("Healthcare")
categories_set.add("Pharmaceuticals")

# added already existed category "IT" which will be ignored
categories_set.add("IT")

print(categories_set)

# function to check wheather a product category is available or not
def is_category_available(category):
    if category in categories_set:
        return True
    else:
        return False
    
print(is_category_available("IT")) # result True
print(is_category_available("xyz")) # result False

# get the total number of unique categories using set
def get_total_categories():
    return len(categories_set)

print(get_total_categories())