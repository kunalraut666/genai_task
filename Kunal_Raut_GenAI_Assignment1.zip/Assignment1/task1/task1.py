# product lists with 6 products
products = ["Mouse", "Keyboard", "Headphone", "Laptop", "Mobile", "Pendrive"]

# sample_product tuple stores for one product
sample_product = ("Mouse", 599, "IT")


# custom function for checking digit will work for both "599" or 599
def is_digit(ele):
    if isinstance(ele, (int, float)):
        return True

    if isinstance(ele, str):
        return ele.isdigit()

    return False


# accessing second and last product
print(products[1])
print(products[-1])

# appending two new products
products.append("Charger")
products.append("Gaming Controller")

print(products)

# converting tuple to list, change price and again back to tuple
converted_list = list(sample_product)

# Since tuple has a fixed structure, price is always at index 1
converted_list[1] = 1599

# If tuple structure was unknown, we could use this instead:
# for idx, val in enumerate(converted_list):
#     if is_digit(val):
#         converted_list[idx] = 1599

sample_product = tuple(converted_list)

print(sample_product)