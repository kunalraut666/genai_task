# creating dict price_dict 
price_dict = {
    "Projector": 689,
    "Cup": 229,
    "Bottle": 179,
    "Scale": 229,
    "Crayons": 359,
    "Organizer": 399
}


# code blocks to add a new product, update the existing ones and remove any existing product
def add_product(prd_name: str, prd_price: int):
    if prd_name in price_dict:
        return "Product already available"
    else:
        price_dict[prd_name] = prd_price
        return "Product added successfully"
    
def update_price_dict(prd_name: str, prd_price: int):
    if prd_name not in price_dict:
        return "Product is not available"
    else:
        price_dict[prd_name] = prd_price
        return "Product updated successfully"
    
def remove_product(prd_name: str):
    if prd_name not in price_dict:
        return "Product is not available"
    else:
        price_dict.pop(prd_name)
        return "Product removed successfully"


print(add_product("Drone", 45000))
print(price_dict)
print(add_product("Trimmer", 1299))
print(price_dict)
print(update_price_dict("Trimmer", 2299))
print(price_dict)
print(remove_product("Trimmer"))
print(price_dict)


# average price of all products
avg = 0
for val in price_dict.values():
    avg += val

avg = avg / len(price_dict)

print(avg)

# print product with maximum and minimum price
# if min() max() is allowed we can directly use that
max_price = float("-inf")
max_product = ""
min_price = float("inf")
min_product = ""

for key, val in price_dict.items():
    if val > max_price:
        max_price = val
        max_product = key

    if val < min_price:
        min_price = val
        min_product = key

print(f"Maximum price: {max_price} and Product name: {max_product}")
print(f"Minimum price: {min_price} and Product name: {min_product}")