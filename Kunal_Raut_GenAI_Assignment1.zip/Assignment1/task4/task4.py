# creating dict price_dict
price_dict = {
    "Projector": 689,
    "Cup": 229,
    "Bottle": 179,
    "Scale": 229,
    "Crayons": 359,
    "Organizer": 399,
    "Mouse": 599,
    "Keyboard": 1299, 
    "Headphone" : 799, 
    "Laptop" : 59999, 
    "Mobile" : 14999, 
    "Pendrive" : 1299
}

# categories dict for accessing categories of the product
categories = {
    "Projector": "Electronics",
    "Cup": "Kitchenware",
    "Bottle": "Accessories",
    "Scale": "Appliances",
    "Crayons": "Stationery",
    "Organizer": "Decor",
    "Mouse": "IT", 
    "Keyboard" : "IT", 
    "Headphone" : "Music", 
    "Laptop" : "IT", 
    "Mobile" : "Electronics", 
    "Pendrive" : "Storage"
}

# creating product list for catalog list
product_list = [item for item in price_dict.keys()]

# creating catalog list
catalog = []

# creating list of tuple (product_name, price, category)
for item in product_list:
    catalog.append((item, price_dict[item], categories[item]))

print(catalog)

# creating new dict category_to_products that maps each category to a list of products names in that category
category_to_products = {}

for prod, val, cate in catalog:
    category_to_products[cate] = [item for item,cat in categories.items() if cat == cate]

print(category_to_products)

# printing all products that belongs to the category that has the maximum number of products.
# if min() max() is allowed we can directly use that
max_no_of_product = 0
max_on_of_key = ""
for key, val in category_to_products.items():
    n = len(val)
    if max_no_of_product < n:
        max_no_of_product = n
        max_on_of_key = key

print(f"Category: {max_on_of_key}\nProducts: {category_to_products[max_on_of_key]}")

