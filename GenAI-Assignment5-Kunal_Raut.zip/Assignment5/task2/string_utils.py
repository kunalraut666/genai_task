def capitalize_words(text: str):
    return ' '.join(list(map(lambda x : x.capitalize(), text.split(" "))))

def reverse_string(text: str):
    return text[::-1]

def word_count(text: str):
    return len(text.split(" "))
