from string_utils import capitalize_words, reverse_string, word_count

text = "hi tutedude! your lectures are very good and easy to understand."

print(capitalize_words(text))
print(reverse_string(text))
print(word_count(text))