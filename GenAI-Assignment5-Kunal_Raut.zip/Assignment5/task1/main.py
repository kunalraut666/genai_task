import math_utils
from math_utils import square

print(math_utils.add(10,20))
print(math_utils.subtract(20,10))
print(square(5))