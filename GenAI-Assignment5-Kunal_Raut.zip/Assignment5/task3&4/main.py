import shop_package.discount as disc
from shop_package.billing import calculate_total, apply_tax

print(disc.apply_discount(1000, 10))
print(calculate_total([100, 200, 300]))

print(disc.flat_discount(1000))
print(apply_tax(1000))