prices = [100, 250, 400, 1200, 50, 2000, 850]

greater_than_500 = lambda x : x > 500
less_than_or_equal_to_500 = lambda x : x <= 500

list1 = list(filter(greater_than_500, prices))
list2 = list(filter(less_than_or_equal_to_500, prices))

print(list1, list2)