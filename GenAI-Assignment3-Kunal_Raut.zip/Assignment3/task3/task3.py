gst = lambda price : price + (0.18 * price)

print(gst(100))

final_price = lambda amount, discount : gst(amount - (amount * discount / 100))

print(final_price(500, 10))