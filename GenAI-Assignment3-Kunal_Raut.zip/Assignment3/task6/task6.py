prices = [100, 250, 400, 1200, 50, 2000, 850]

def process_prices(prices):
    discount_list = list(map(lambda x : x - (x*10 / 100), prices))

    filtered_price = list(filter(lambda x : x > 300, discount_list))

    return discount_list, filtered_price

discount, filtered = process_prices(prices)
print(discount, filtered)