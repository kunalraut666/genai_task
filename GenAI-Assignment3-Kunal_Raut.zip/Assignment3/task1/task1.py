def apply_discount(price, discount_percent = 5):
    return price - (price * discount_percent) / 100 if discount_percent <= 60 else "Can't provide more than 60%"

print(apply_discount(1000, 10))
print(apply_discount(500))
print(apply_discount(5500, 61))