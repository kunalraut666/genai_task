def add_price(prices_list, price):
    prices_list.append(price)
    return prices_list

def get_average_price(prices_list):
    return sum(prices_list) / len(prices_list)

def get_max_price(prices_list):
    return max(prices_list)

res = []

while True:
    print("1-Add price")
    print("2-Show average price")
    print("3-Show highest price")
    print("q-Quit")

    choice = input("Enter choice: ")
    
    if choice == "1":
        n = int(input("Enter number: "))
        res = add_price(res, n)
        print("Added!")

    elif choice == "2":
        print(get_average_price(res))

    elif choice == "3":
        print(get_max_price(res))

    elif choice == "q":
        exit()

    else:
        print("Invalid input")
        continue

